namespace Web.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

   
    }
}