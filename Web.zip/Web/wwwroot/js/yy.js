﻿
//js文件要引入到挂载的后面


const HelloVueApp = {
    data() {
        return {
            message: '排班管理'
        }
    }
};

Vue.createApp(HelloVueApp).mount('#app');




const HelloVueApp1 = {
    data() {
        return {
            message1: '病人管理'
        }
    }
};

Vue.createApp(HelloVueApp1).mount('#app1');




const HelloVueApp2 = {
    data() {
        return {
            message3: '诊断报告'
        }
    }
};

Vue.createApp(HelloVueApp2).mount('#app2');


const HelloVueApp3 = {
    data() {
        return {
            message4: '预警'
        }
    }
};

Vue.createApp(HelloVueApp3).mount('#app3');

const HelloVueApp4 = {
    data() {
        return {
            message5: '床位管理'
        }
    }
};

Vue.createApp(HelloVueApp4).mount('#app4');




const HelloVueApp5 = {
    data() {
        return {
            message6: '药品库存'
        }
    }
};

Vue.createApp(HelloVueApp5).mount('#app5');


const HelloVueApp6 = {
    data() {
        return {
            message7: '退出登录',

        }
    }
  
};



Vue.createApp(HelloVueApp6).mount('#app6');




const HelloVueApp7 = {
    data() {
        return {
            message8: '用户:',
            message9: " ",
            message10: '上班时间：9:00 - 12:30'
        }
    }
};

Vue.createApp(HelloVueApp7).mount('#app7');



const HelloVueApp9 = {
    data() {
        return {
            showMenu: "修改账号",
            showMenu1: "反馈"
        }
    }
};

Vue.createApp(HelloVueApp9).mount('#h11');




